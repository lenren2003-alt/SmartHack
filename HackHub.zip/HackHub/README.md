# HackHub

Full-stack project organized as:
```
HackHub/
├── client/   # React + Vite frontend (JSX)
│   └── src/components/   # All page components (.jsx)
└── server/   # Express + MongoDB backend
    └── models/
```

## Run the client
```
cd client
npm install
npm run dev
```

## Run the server
```
cd server
cp .env.example .env   # edit MONGO_URI / JWT_SECRET
npm install
npm run dev
```

Requires Node.js 20.19+ (or 22 LTS) and MongoDB running locally (or a connection string).
