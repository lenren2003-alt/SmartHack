import {, useNavigate } from "react-router-dom";
import { useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import lockCloud from "@/assets/lock-cloud.png";

export const Route =("/recover-password")({
  head: () => ({ meta: [{ title: "Recover Password — SmartHack" }] }),
  component,
});

function RecoverPasswordPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const handleSend = (e) => {
    e.preventDefault();
    if (!username.trim() || !email.trim()) return setError("⚠️ All fields are required.");
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError("⚠️ Please enter a valid email.");
    setError("");
    // Demo: persist target email so verify-code & change-password know who to update
    localStorage.setItem("smarthack_recover_email", email);
    alert("Recovery code sent to your email! (demo: use code 12345)");
    navigate("/verify-code");
  };

  const inputClass = "w-full mb-3 px-4 py-3 rounded-full bg-[#1f3a68] text-white placeholder-white/60 outline-none";

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader />
      <div className="bg-[#5B8FCF] min-h-[calc(100vh-72px)] grid md:grid-cols-2 items-center px-6 py-10 gap-8 relative">
        <button onClick={() => navigate("/login")} className="absolute right-6 top-6 text-white text-2xl">←</button>

        <div className="hidden md:flex justify-center">
          <img src={lockCloud} alt="Yellow padlock on cloud" loading="lazy" width={360} height={360} className="w-72 h-auto" />
        </div>

        <form onSubmit={handleSend} className="w-full max-w-md mx-auto">
          <h1 className="text-white text-3xl font-bold text-center mb-8">Recover Password</h1>
          <input className={inputClass} placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
          <input className={inputClass} type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          {error && <p className="text-red-100 text-sm text-center mb-3">{error}</p>}
          <div className="flex justify-center mt-2">
            <button type="submit" className="bg-[#cfe0f3] text-[#1f3a68] font-bold rounded-full px-10 py-2.5 hover:opacity-90">Send Code</button>
          </div>
        </form>
      </div>
    </div>
  );
}
