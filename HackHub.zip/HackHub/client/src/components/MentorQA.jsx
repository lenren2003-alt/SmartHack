import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { currentUser, type StoredUser } from "@/lib/auth";
import {
  answerQuestion,
  askQuestion,
  getQuestions,
  isJoined,
  mentorForHackathon,
  type Hackathon,
  type Question,
} from "@/lib/store";

type Props = { hackathon: Hackathon };

export function MentorQA({ hackathon }: Props) {
  const [user, setUser] = useState<StoredUser | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [draft, setDraft] = useState("");
  const [answerDrafts, setAnswerDrafts] = useState<Record<string, string>>({});
  const [aiLoadingId, setAiLoadingId] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  const refresh = () => setQuestions(getQuestions(hackathon.id).sort((a, b) => b.createdAt - a.createdAt));

  useEffect(() => {
    setUser(currentUser());
    refresh();
  }, [hackathon.id]);

  const assignedMentorEmail = mentorForHackathon(hackathon.id);
  const isMentor =
    !!user &&
    user.role === "mentor" &&
    !!assignedMentorEmail &&
    user.email.toLowerCase() === assignedMentorEmail.toLowerCase();
  const canAsk = !!user && user.role === "participant" && isJoined(hackathon.id);

  const handleAsk = async () => {
    if (!draft.trim()) return;
    setSubmitting(true);
    try {
      askQuestion(hackathon.id, draft);
      setDraft("");
      refresh();
    } catch (e) {
      alert(e instanceof Error ? e.message : "Failed to post question.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleAnswer = (qid: string) => {
    const text = (answerDrafts[qid] || "").trim();
    if (!text) return;
    answerQuestion(qid, text, "mentor");
    setAnswerDrafts((p) => ({ ...p, [qid]: "" }));
    refresh();
  };

  const handleAskAi = async (q: Question) => {
    setAiLoadingId(q.id);
    setAiError("");
    try {
      const res = await fetch("/api/ask-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: q.question,
          hackathonTitle: hackathon.title,
          hackathonTheme: hackathon.theme,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "AI request failed");
      answerQuestion(q.id, data.answer, "ai", { email: "ai@smarthack", name: "SmartHack AI" });
      refresh();
    } catch (e) {
      setAiError(e instanceof Error ? e.message : "AI failed.");
    } finally {
      setAiLoadingId(null);
    }
  };

  return (
    <div className="rounded-xl border bg-white shadow-sm p-5 mt-6">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-bold text-[#1f3a68]">💬 Mentor Q&A</h2>
        <span className="text-xs text-gray-500">
          {questions.length} {questions.length === 1 ? "question" : "questions"}
        </span>
      </div>

      {canAsk ? (
        <div className="bg-[#cfe0f3]/40 rounded-md p-3 mb-4">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            maxLength={500}
            rows={2}
            placeholder="Ask the mentor anything about this hackathon…"
            className="w-full rounded border border-gray-300 px-3 py-2 text-sm bg-white"
          />
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-gray-500">{draft.length}/500</span>
            <button
              onClick={handleAsk}
              disabled={submitting || !draft.trim()}
              className="bg-[#5B8FCF] text-white text-sm font-semibold rounded-md px-4 py-1.5 disabled:opacity-50"
            >
              Post question
            </button>
          </div>
        </div>
      ) : !user ? (
        <p className="text-sm text-gray-600 mb-4">
          <Link to="/login" className="text-[#5B8FCF] hover:underline font-semibold">
            Log in
          </Link>{" "}
          and join this hackathon to ask the mentor questions.
        </p>
      ) : user.role === "participant" && !isJoined(hackathon.id) ? (
        <p className="text-sm text-gray-600 mb-4">Join this hackathon to ask questions.</p>
      ) : null}

      {aiError && (
        <div className="mb-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">
          {aiError}
        </div>
      )}

      {questions.length === 0 ? (
        <p className="text-sm text-gray-500 italic text-center py-4">
          No questions yet. Be the first to ask!
        </p>
      ) : (
        <ul className="space-y-3">
          {questions.map((q) => {
            const isMine = user?.email.toLowerCase() === q.askerEmail.toLowerCase();
            return (
              <li key={q.id} className="border rounded-md p-3 bg-white">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-[#1f3a68]">
                      {q.askerName} <span className="text-gray-400 font-normal text-xs">asked</span>
                    </p>
                    <p className="text-sm text-gray-800 mt-0.5">{q.question}</p>
                  </div>
                  <span className="text-[10px] text-gray-400 whitespace-nowrap">
                    {new Date(q.createdAt).toLocaleDateString()}
                  </span>
                </div>

                {q.answer ? (
                  <div className="mt-2 bg-green-50 border border-green-200 rounded p-2.5">
                    <p className="text-xs font-semibold text-green-800 flex items-center gap-1">
                      {q.answererRole === "ai" ? "🤖" : "🎓"} {q.answererName}
                      <span className="text-green-600 font-normal">
                        ({q.answererRole === "ai" ? "AI" : "Mentor"})
                      </span>
                    </p>
                    <p className="text-sm text-gray-800 mt-1 whitespace-pre-wrap">{q.answer}</p>
                  </div>
                ) : (
                  <div className="mt-2 flex flex-col gap-2">
                    {isMentor && (
                      <div className="flex gap-2">
                        <input
                          value={answerDrafts[q.id] || ""}
                          onChange={(e) =>
                            setAnswerDrafts((p) => ({ ...p, [q.id]: e.target.value }))
                          }
                          placeholder="Write your answer…"
                          className="flex-1 rounded border border-gray-300 px-2 py-1 text-sm"
                        />
                        <button
                          onClick={() => handleAnswer(q.id)}
                          className="bg-[#5B8FCF] text-white text-xs font-semibold rounded px-3 py-1"
                        >
                          Reply
                        </button>
                      </div>
                    )}
                    {(isMine || isMentor) && (
                      <button
                        onClick={() => handleAskAi(q)}
                        disabled={aiLoadingId === q.id}
                        className="self-start text-xs bg-purple-600 text-white font-semibold rounded px-3 py-1 disabled:opacity-50"
                      >
                        {aiLoadingId === q.id ? "Thinking…" : "🤖 Ask AI"}
                      </button>
                    )}
                    {!isMentor && !isMine && (
                      <p className="text-xs text-gray-500 italic">Awaiting mentor answer…</p>
                    )}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
