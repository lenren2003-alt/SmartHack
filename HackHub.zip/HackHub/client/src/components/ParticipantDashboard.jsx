import {, Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { currentUser } from "@/lib/auth";
import {
  leaveHackathon,
  myJoinedHackathons,
  mySubmissions,
  type Hackathon,
  type Submission,
} from "@/lib/store";

export const Route =("/participant-dashboard")({
  head: () => ({ meta: [{ title: "Participant Dashboard — SmartHack" }] }),
  component,
});

function ParticipantDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"Your Hackathons" | "Notifications">("Your Hackathons");
  const [items, setItems] = useState<Hackathon[]>([]);
  const [subs, setSubs] = useState<Submission[]>([]);

  const refresh = () => {
    setItems(myJoinedHackathons());
    setSubs(mySubmissions());
  };

  useEffect(() => {
    if (!currentUser()) navigate("/login");
    refresh();
  }, [navigate]);

  const handleLeave = (id: string, title: string) => {
    if (!window.confirm(`Leave "${title}"?`)) return;
    leaveHackathon(id);
    refresh();
  };

  const submittedFor = (hid: string) => subs.find((s) => s.hackathonId === hid);

  const notifications = [
    ...subs.map((s) => ({
      id: `sub-${s.id}`,
      text: `Project "${s.projectTitle}" submitted — status: ${s.status}.`,
    })),
    ...items
      .filter((h) => !submittedFor(h.id))
      .map((h) => ({ id: `due-${h.id}`, text: `Reminder: submission still open for ${h.title}.` })),
  ];

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <SiteHeader active="dashboard" />

      <section className="bg-[#5B8FCF] py-5 relative">
        <h1 className="text-center text-[#1f3a68] text-2xl font-bold">Participant Dashboard</h1>
        <button
          onClick={() => navigate("/settings")}
          className="absolute top-1/2 right-10 -translate-y-1/2 w-11 h-11 rounded-full bg-white flex items-center justify-center text-2xl"
          title="Profile"
        >
          👩
        </button>
      </section>

      <main className="flex-1 max-w-3xl mx-auto w-full p-6">
        <div className="flex justify-center mb-6">
          {(["Your Hackathons", "Notifications"] ).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2 border border-gray-300 text-sm ${
                activeTab === tab ? "bg-white text-black font-semibold" : "bg-gray-100 text-gray-400"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {activeTab === "Your Hackathons" && (
          <div className="space-y-4">
            {items.length === 0 && (
              <div className="text-center text-gray-500 py-10">
                You haven't joined any hackathon yet.{" "}
                <Link to="/hackathons" className="text-[#5B8FCF] underline">Browse hackathons</Link>
              </div>
            )}
            {items.map((h) => {
              const sub = submittedFor(h.id);
              return (
                <div key={h.id} className="border border-gray-300 rounded-lg p-5 bg-white">
                  <h3 className="font-bold text-base mb-2">{h.title}</h3>
                  <p className="text-sm mb-1">
                    <span className="font-semibold">Status:</span>{" "}
                    <span className={`font-semibold ${sub ? "text-blue-600" : "text-green-600"}`}>
                      {sub ? `Submitted (${sub.status})` : "Joined"}
                    </span>
                  </p>
                  <p className="text-sm mb-1"><span className="font-semibold">Timeline:</span> {h.startDate} → {h.endDate}</p>
                  <p className="text-sm text-gray-700 mb-3">{h.description}</p>

                  <div className="flex flex-wrap gap-3">
                    <Link
                      to="/hackathon-details/$id"
                      params={{ id: h.id }}
                      className="bg-black text-white text-xs font-semibold rounded px-4 py-2"
                    >
                      View Details
                    </Link>
                    {!sub && (
                      <Link
                        to="/submit-project"
                        search={{ hackathonId: h.id }}
                        className="bg-white border border-black text-black text-xs font-semibold rounded px-4 py-2"
                      >
                        Submit Project
                      </Link>
                    )}
                    <button
                      onClick={() => handleLeave(h.id, h.title)}
                      className="bg-red-600 text-white text-xs font-semibold rounded px-4 py-2"
                    >
                      Leave
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === "Notifications" && (
          <div className="space-y-3">
            {notifications.length === 0 && (
              <div className="text-center text-gray-500 py-10">No notifications.</div>
            )}
            {notifications.map((n) => (
              <div key={n.id} className="border border-gray-300 rounded-lg p-4 bg-white text-sm">
                {n.text}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
