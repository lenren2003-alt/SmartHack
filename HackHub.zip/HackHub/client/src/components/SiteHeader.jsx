import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { currentUser, dashboardPathFor, logout, type StoredUser } from "@/lib/auth";

type Props = { active?: "home" | "about" | "dashboard" | "hackathons" | "settings" | "history" };

export function SiteHeader({ active }: Props) {
  const [user, setUser] = useState<StoredUser | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    setUser(currentUser());
  }, []);

  const linkClass = (key: Props["active"]) =>
    `text-sm font-medium hover:text-[#5B8FCF] transition ${
      active === key ? "underline underline-offset-4 text-[#1f3a68] font-semibold" : "text-[#1f3a68]"
    }`;

  const handleLogout = () => {
    logout();
    setUser(null);
    navigate({ to: "/" });
  };

  return (
    <header className="border-b bg-white">
      <div className="container mx-auto flex items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="h-8 w-8 rounded bg-[#5B8FCF] text-white font-bold flex items-center justify-center">
            S
          </div>
          <div className="leading-tight">
            <div className="font-bold text-[#1f3a68]">
              Smart<span className="text-[#5B8FCF]">Hack</span>
            </div>
            <div className="text-xs text-gray-500">Management System</div>
          </div>
        </Link>

        <nav className="flex items-center gap-6">
          <Link to="/" className={linkClass("home")}>Home</Link>
          <Link to="/about" className={linkClass("about")}>About Us</Link>
          {user && (
            <Link
              to={dashboardPathFor(user.role)}
              className={linkClass("dashboard")}
            >
              Dashboard
            </Link>
          )}
          <Link to="/hackathons" className={linkClass("hackathons")}>Hackathons</Link>
          {user && <Link to="/history" className={linkClass("history")}>History</Link>}
          <Link to="/settings" className={linkClass("settings")}>Settings</Link>

          {user ? (
            <button
              onClick={handleLogout}
              className="rounded-md bg-[#5B8FCF] px-3 py-1.5 text-sm font-semibold text-white hover:opacity-90"
            >
              Log out
            </button>
          ) : (
            <Link
              to="/login"
              className="rounded-md bg-[#5B8FCF] px-3 py-1.5 text-sm font-semibold text-white hover:opacity-90"
            >
              Log in
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
