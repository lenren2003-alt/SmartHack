import {, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { z } from "zod";
import { SiteHeader } from "@/components/SiteHeader";
import { currentUser } from "@/lib/auth";
import { getHackathon, myJoinedHackathons, submitProject, type Hackathon } from "@/lib/store";

export const Route =("/submit-project")({
  head: () => ({ meta: [{ title: "Submit Project — SmartHack" }] }),
  validateSearch: (s) => z.object({ hackathonId: z.string().optional() }).parse(s),
  component,
});

function SubmitProjectPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();

  const [available, setAvailable] = useState<Hackathon[]>([]);
  const [hackathonId, setHackathonId] = useState(search.hackathonId || "");
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [members, setMembers] = useState("");
  const [category, setCategory] = useState("AI");
  const [fileName, setFileName] = useState<string | undefined>();
  const [error, setError] = useState("");

  useEffect(() => {
    const me = currentUser();
    if (!me) {
      navigate("/login");
      return;
    }
    const joined = myJoinedHackathons();
    setAvailable(joined);
    if (!hackathonId && joined[0]) setHackathonId(joined[0].id);
    if (search.hackathonId) {
      const h = getHackathon(search.hackathonId);
      if (h) setCategory(h.category);
    }
  }, [navigate, hackathonId, search.hackathonId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!hackathonId) return setError("⚠️ Please select a hackathon (you must join one first).");
    if (!title.trim() || !desc.trim()) return setError("⚠️ Title and description are required.");
    setError("");
    submitProject({
      hackathonId,
      projectTitle: title.trim(),
      description: desc.trim(),
      teamMembers: members.trim(),
      category,
      fileName,
    });
    navigate("/confirmation");
  };

  const inputClass = "w-full p-2.5 rounded-md border border-gray-300 bg-gray-50 text-sm";

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader active="dashboard" />
      <header className="bg-[#5B8FCF] py-6 text-center">
        <h1 className="text-2xl font-bold text-[#1f3a68]">Submit your Project</h1>
        <p className="text-sm text-white/90">Fill out the details and upload your files to participate.</p>
      </header>

      <main className="max-w-4xl mx-auto p-8">
        {available.length === 0 ? (
          <div className="text-center text-gray-600 py-10">
            You need to join a hackathon first. <a href="/hackathons" className="text-[#5B8FCF] underline">Browse hackathons</a>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <label className="block font-semibold text-sm mb-2">Select Hackathon</label>
                <select className={inputClass} value={hackathonId} onChange={(e) => setHackathonId(e.target.value)}>
                  {available.map((h) => <option key={h.id} value={h.id}>{h.title}</option>)}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-sm mb-2">Project Name</label>
                <input className={inputClass} value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <div>
                <label className="block font-semibold text-sm mb-2">Project Description</label>
                <textarea className={inputClass} rows={4} value={desc} onChange={(e) => setDesc(e.target.value)} />
              </div>
              <div>
                <label className="block font-semibold text-sm mb-2">Team Members</label>
                <input className={inputClass} value={members} onChange={(e) => setMembers(e.target.value)} placeholder="e.g. Farah, Layal, Mariya" />
              </div>
              <div>
                <label className="block font-semibold text-sm mb-2">Category</label>
                <select className={inputClass} value={category} onChange={(e) => setCategory(e.target.value)}>
                  <option>AI</option><option>Web</option><option>Mobile</option>
                  <option>Data Science</option><option>Cybersecurity</option><option>Game Development</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-sm mb-2">Upload file here:</label>
              <label className="block border-2 border-dashed border-gray-300 rounded-lg p-10 text-center cursor-pointer hover:bg-gray-50">
                <div className="text-4xl text-[#5B8FCF] mb-2">☁️</div>
                <div className="text-sm">{fileName || "Drag and drop files here"}</div>
                <div className="text-xs text-gray-500 my-2">or</div>
                <span className="inline-block bg-[#5B8FCF] text-white text-sm font-semibold rounded-md px-4 py-1.5">Browse Files</span>
                <input type="file" className="hidden" onChange={(e) => setFileName(e.target.files?.[0]?.name)} />
              </label>

              {error && <p className="text-red-500 text-sm font-medium mt-3">{error}</p>}

              <div className="flex justify-end mt-5">
                <button type="submit" className="bg-[#5B8FCF] text-white font-semibold px-7 py-2.5 rounded-md hover:opacity-90">
                  Submit
                </button>
              </div>
            </div>
          </form>
        )}
      </main>
    </div>
  );
}
