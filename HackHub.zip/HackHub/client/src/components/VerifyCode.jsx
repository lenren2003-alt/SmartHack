import {, useNavigate } from "react-router-dom";
import { useRef, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import lockCloud from "@/assets/lock-cloud.png";

export const Route =("/verify-code")({
  head: () => ({ meta: [{ title: "Verify Code — SmartHack" }] }),
  component,
});

const DEMO_CODE = "12345";

function VerifyCodePage() {
  const navigate = useNavigate();
  const [code, setCode] = useState(["", "", "", "", ""]);
  const [error, setError] = useState("");
  const inputRefs = useRef<Array<HTMLInputElement | null>>([]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const next = [...code];
    next[index] = value.slice(-1);
    setCode(next);
    setError("");
    if (value && index < 4) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e) => {
    if (e.key === "Backspace" && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSend = () => {
    if (code.some((d) => d === "")) return setError("⚠️ Please enter the full 5-digit code.");
    if (code.join("") !== DEMO_CODE) return setError("⚠️ Invalid code. (demo: 12345)");
    navigate("/change-password");
  };

  const handleResend = () => {
    setCode(["", "", "", "", ""]);
    setError("");
    inputRefs.current[0]?.focus();
  };

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader />
      <div className="bg-[#5B8FCF] min-h-[calc(100vh-72px)] grid md:grid-cols-2 items-center px-6 py-10 gap-8 relative">
        <button onClick={() => navigate("/recover-password")} className="absolute right-6 top-6 text-white text-2xl">←</button>

        <div className="hidden md:flex justify-center">
          <img src={lockCloud} alt="Yellow padlock on cloud" loading="lazy" width={360} height={360} className="w-72 h-auto" />
        </div>

        <div className="w-full max-w-md mx-auto">
          <h1 className="text-white text-3xl font-bold text-center mb-8">Verify Code</h1>
          <div className="flex justify-center gap-2.5 mb-4">
            {code.map((digit, idx) => (
              <input
                key={idx}
                ref={(el) => { inputRefs.current[idx] = el; }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(idx, e.target.value)}
                onKeyDown={(e) => handleKeyDown(idx, e)}
                className="w-14 h-14 bg-[#1f3a68] text-white text-2xl font-bold text-center rounded-lg outline-none"
              />
            ))}
          </div>
          {error && <p className="text-red-100 text-sm text-center mb-3">{error}</p>}
          <div className="text-center mb-4">
            <button onClick={handleResend} className="text-white underline font-semibold text-sm">Resend Code</button>
          </div>
          <div className="flex justify-center">
            <button onClick={handleSend} className="bg-[#cfe0f3] text-[#1f3a68] font-bold rounded-full px-12 py-2.5 hover:opacity-90">
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
