import {, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { currentUser } from "@/lib/auth";
import { evaluationFor, submissionsForJudge, type Hackathon, type Submission } from "@/lib/store";

export const Route =("/judge-dashboard")({
  head: () => ({ meta: [{ title: "Judge Dashboard — SmartHack" }] }),
  component,
});

function JudgeDashboardPage() {
  const navigate = useNavigate();
  const [items, setItems] = useState<{ sub: Submission; hackathon?: Hackathon }[]>([]);

  useEffect(() => {
    if (!currentUser()) navigate("/login");
    setItems(submissionsForJudge());
  }, [navigate]);

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <SiteHeader active="dashboard" />
      <section className="bg-[#5B8FCF] py-5">
        <h1 className="text-center text-white text-2xl font-bold">Judge Dashboard</h1>
      </section>

      <main className="flex-1 max-w-4xl mx-auto w-full p-8">
        <div className="rounded-xl border bg-white p-8 shadow-sm">
          <h2 className="text-xl font-bold border-b pb-3 mb-5">Assigned Projects</h2>

          {items.length === 0 ? (
            <p className="text-gray-500 text-sm">
              No assigned submissions yet. An admin must assign you .
            </p>
          ) : (
            <ul className="space-y-3">
              {items.map(({ sub, hackathon }) => {
                const ev = evaluationFor(sub.id);
                return (
                  <li key={sub.id} className="bg-[#5B8FCF]/30 rounded-md p-4 flex justify-between items-center">
                    <div>
                      <p className="font-semibold">{sub.projectTitle}</p>
                      <p className="text-sm"><span className="font-semibold">Hackathon:</span> {hackathon?.title || "—"}</p>
                      <p className="text-sm"><span className="font-semibold">Team:</span> {sub.teamMembers || "—"}</p>
                      {ev && <p className="text-xs text-green-700 font-semibold mt-1">✓ Evaluated</p>}
                    </div>
                    <button
                      onClick={() => navigate({ to: "/evaluation", search: { submissionId: sub.id } })}
                      className="bg-[#5B8FCF] text-white font-semibold rounded-md px-5 py-2 hover:opacity-90"
                    >
                      {ev ? "View" : "Evaluate"}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </main>
    </div>
  );
}
