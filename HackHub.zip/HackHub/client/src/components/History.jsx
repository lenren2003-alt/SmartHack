import {, Link, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { currentUser, type StoredUser } from "@/lib/auth";
import {
  getAssignments,
  getEvaluations,
  getHackathons,
  getMentorAssignments,
  getRegistrations,
  getSubmissions,
  type Hackathon,
} from "@/lib/store";

export const Route =("/history")({
  head: () => ({ meta: [{ title: "History — SmartHack" }] }),
  component,
});

date: number;
  icon: string;
  title: string;
  detail: string;
  hackathonId?: string;
};

function HistoryPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState<StoredUser | null>(null);
  const [entries, setEntries] = useState<HistoryEntry[]>([]);

  useEffect(() => {
    const u = currentUser();
    if (!u) {
      navigate("/login");
      return;
    }
    setUser(u);
    setEntries(buildHistory(u));
  }, [navigate]);

  const grouped = useMemo(() => {
    const sorted = [...entries].sort((a, b) => b.date - a.date);
    return sorted;
  }, [entries]);

  if (!user) return null;

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader active="dashboard" />
      <section className="bg-[#5B8FCF] py-6 text-center">
        <h1 className="text-2xl font-bold text-white">My History</h1>
        <p className="text-white/90 text-sm mt-1 capitalize">{user.role} — {user.fullName}</p>
      </section>

      <main className="max-w-3xl mx-auto p-8">
        <div className="rounded-xl border bg-white p-6 shadow-sm">
          <h2 className="font-bold text-[#1f3a68] mb-4 border-b pb-3">Activity Timeline</h2>
          {grouped.length === 0 ? (
            <p className="text-sm text-gray-500 py-6 text-center">
              No activity yet. Start by{" "}
              <Link to="/hackathons" className="text-[#5B8FCF] hover:underline font-semibold">
                browsing hackathons
              </Link>.
            </p>
          ) : (
            <ul className="space-y-3">
              {grouped.map((e) => (
                <li key={e.id} className="flex gap-3 items-start bg-[#cfe0f3]/40 rounded-md p-3">
                  <div className="text-2xl">{e.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-semibold text-[#1f3a68]">{e.title}</p>
                      <p className="text-xs text-gray-500 whitespace-nowrap">
                        {new Date(e.date).toLocaleDateString()}
                      </p>
                    </div>
                    <p className="text-sm text-gray-700 mt-0.5">{e.detail}</p>
                    {e.hackathonId && (
                      <Link
                        to="/hackathon-details/$id"
                        params={{ id: e.hackathonId }}
                        className="text-xs text-[#5B8FCF] hover:underline font-semibold"
                      >
                        View hackathon →
                      </Link>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </main>
    </div>
  );
}

function buildHistory(user): HistoryEntry[] {
  const email = user.email.toLowerCase();
  const hackathons = getHackathons();
  const hackById = (id: string)=> hackathons.find((h) => h.id === id);
  const out= [];

  // Account creation (no real timestamp — use 0 )
  out.push({
    id: `acct-${email}`,
    date: 0,
    icon: "🎉",
    title: "Account created",
    detail: `Joined SmartHack ${user.role}.`,
  });

  if (user.role === "participant") {
    // Joined hackathons
    getRegistrations()
      .filter((r) => r.participantEmail.toLowerCase() === email)
      .forEach((r, i) => {
        const h = hackById(r.hackathonId);
        if (!h) return;
        out.push({
          id: `join-${r.hackathonId}-${i}`,
          date: new Date(h.startDate).getTime() || Date.now(),
          icon: "✅",
          title: `Joined "${h.title}"`,
          detail: `${h.theme} • ${h.location}`,
          hackathonId: h.id,
        });
      });
    // Submissions
    getSubmissions()
      .filter((s) => s.participantEmail.toLowerCase() === email)
      .forEach((s) => {
        const h = hackById(s.hackathonId);
        out.push({
          id: `sub-${s.id}`,
          date: s.createdAt,
          icon: "📤",
          title: `Submitted "${s.projectTitle}"`,
          detail: `${h?.title || "Hackathon"} — Status: ${s.status}`,
          hackathonId: s.hackathonId,
        });
      });
  }

  if (user.role === "judge") {
    // Hackathons assigned to judge
    getAssignments()
      .filter((a) => a.judgeEmail.toLowerCase() === email)
      .forEach((a, i) => {
        const h = hackById(a.hackathonId);
        if (!h) return;
        out.push({
          id: `jassign-${a.hackathonId}-${i}`,
          date: new Date(h.startDate).getTime() || Date.now(),
          icon: "⚖️",
          title: `Assigned to judge "${h.title}"`,
          detail: `${h.theme} • ${h.location}`,
          hackathonId: h.id,
        });
      });
    // Evaluations completed
    const subs = getSubmissions();
    getEvaluations()
      .filter((e) => e.judgeEmail.toLowerCase() === email)
      .forEach((e) => {
        const sub = subs.find((s) => s.id === e.submissionId);
        const h = sub ? hackById(sub.hackathonId) : undefined;
        const total = e.innovation + e.design + e.functionality;
        out.push({
          id: `eval-${e.id}`,
          date: e.createdAt,
          icon: "📝",
          title: `Evaluated "${sub?.projectTitle || "submission"}"`,
          detail: `${h?.title || ""} — Score: ${total}/30`,
          hackathonId: sub?.hackathonId,
        });
      });
  }

  if (user.role === "mentor") {
    getMentorAssignments()
      .filter((a) => a.mentorEmail.toLowerCase() === email)
      .forEach((a, i) => {
        const h = hackById(a.hackathonId);
        if (!h) return;
        out.push({
          id: `massign-${a.hackathonId}-${i}`,
          date: new Date(h.startDate).getTime() || Date.now(),
          icon: "🎓",
          title: `Mentoring "${h.title}"`,
          detail: `${h.theme} • ${h.location}`,
          hackathonId: h.id,
        });
      });
  }

  if (user.role === "organizer") {
    hackathons
      .filter((h) => h.organizerEmail.toLowerCase() === email)
      .forEach((h) => {
        out.push({
          id: `created-${h.id}`,
          date: new Date(h.startDate).getTime() || Date.now(),
          icon: "🏆",
          title: `Created "${h.title}"`,
          detail: `${h.theme} • ${h.location}`,
          hackathonId: h.id,
        });
      });
  }

  if (user.role === "admin") {
    out.push({
      id: "admin-overview",
      date: Date.now(),
      icon: "🛡️",
      title: "Admin overview",
      detail: `${hackathons.length} hackathons, ${getSubmissions().length} submissions, ${getEvaluations().length} evaluations on the platform.`,
    });
  }

  return out;
}
