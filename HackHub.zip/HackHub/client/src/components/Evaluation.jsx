import {, Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { z } from "zod";
import { SiteHeader } from "@/components/SiteHeader";
import {
  evaluateSubmission,
  evaluationFor,
  getHackathon,
  getSubmissions,
  type Submission,
} from "@/lib/store";

export const Route =("/evaluation")({
  head: () => ({ meta: [{ title: "Project Evaluation — SmartHack" }] }),
  validateSearch: (s) => z.object({ submissionId: z.string().optional() }).parse(s),
  component,
});

const starColors = ["#22c55e", "#84cc16", "#eab308", "#f97316", "#ef4444"];

function StarRow({ value, onChange, disabled }: { value: number; onChange: (n: number) => void; disabled?: boolean }) {
  return (
    <div className="flex gap-1.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <span
          key={n}
          onClick={() => !disabled && onChange(n)}
          className={`text-2xl ${disabled ? "" : "cursor-pointer"}`}
          style={{ color: starColors[n - 1] }}
        >
          {n <= value ? "★" : "☆"}
        </span>
      ))}
    </div>
  );
}

function EvaluationPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [sub, setSub] = useState<Submission | undefined>();
  const [innovation, setInnovation] = useState(0);
  const [design, setDesign] = useState(0);
  const [functionality, setFunctionality] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [error, setError] = useState("");
  const [readonly, setReadonly] = useState(false);

  useEffect(() => {
    const s = search.submissionId
      ? getSubmissions().find((x) => x.id === search.submissionId)
      : getSubmissions()[0];
    setSub(s);
    if (s) {
      const ev = evaluationFor(s.id);
      if (ev) {
        setInnovation(ev.innovation);
        setDesign(ev.design);
        setFunctionality(ev.functionality);
        setFeedback(ev.feedback);
        setReadonly(true);
      }
    }
  }, [search.submissionId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!sub) return;
    if (!innovation || !design || !functionality || !feedback.trim()) {
      setError("⚠️ All fields are required.");
      return;
    }
    setError("");
    evaluateSubmission({ submissionId: sub.id, innovation, design, functionality, feedback: feedback.trim() });
    navigate("/evaluation-submitted");
  };

  const hack = sub ? getHackathon(sub.hackathonId) : undefined;

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader active="dashboard" />
      <header className="bg-[#5B8FCF] px-6 py-4 flex items-center justify-between">
        <h1 className="text-white text-xl font-bold">Project Evaluation</h1>
        <Link to="/judge-dashboard" className="text-white text-2xl">←</Link>
      </header>

      <main className="max-w-4xl mx-auto p-8">
        {!sub ? (
          <p className="text-center text-gray-500">No submission selected.</p>
        ) : (
          <form onSubmit={handleSubmit} className="rounded-xl border bg-white p-8 shadow-sm">
            <div className="border-b pb-3 mb-6 text-center">
              <h2 className="text-lg"><strong>Project:</strong> {hack?.title || "—"}</h2>
            </div>

            <div className="grid md:grid-cols-[1fr_1.3fr] gap-8">
              <div className="bg-[#5B8FCF]/25 rounded-lg p-5 text-sm leading-relaxed space-y-2">
                <p><strong>Project title:</strong> <span className="text-[#5B8FCF]">{sub.projectTitle}</span></p>
                <p><strong>Team Members:</strong> <span className="text-[#5B8FCF]">{sub.teamMembers || "—"}</span></p>
                <p><strong>Description:</strong> <span className="text-[#5B8FCF]">{sub.description}</span></p>
                <p><strong>Category:</strong> <span className="text-[#5B8FCF]">{sub.category}</span></p>
                {sub.fileName && <p><strong>File:</strong> <span className="text-[#5B8FCF]">{sub.fileName}</span></p>}
              </div>

              <div>
                <h3 className="font-bold mb-4">Scoring ⭐ {readonly && <span className="text-xs text-green-700">(already evaluated)</span>}</h3>
                <div className="flex items-center gap-4 mb-3">
                  <label className="w-28 font-medium">Innovation:</label>
                  <StarRow value={innovation} onChange={setInnovation} disabled={readonly} />
                </div>
                <div className="flex items-center gap-4 mb-3">
                  <label className="w-28 font-medium">Design:</label>
                  <StarRow value={design} onChange={setDesign} disabled={readonly} />
                </div>
                <div className="flex items-center gap-4 mb-5">
                  <label className="w-28 font-medium">Functionality:</label>
                  <StarRow value={functionality} onChange={setFunctionality} disabled={readonly} />
                </div>

                <label className="block font-medium mb-2">Feedback:</label>
                <textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  rows={4}
                  disabled={readonly}
                  className="w-full rounded-md border border-gray-300 p-2.5 text-sm disabled:bg-gray-50"
                />

                {error && <p className="text-red-500 text-sm font-medium mt-3">{error}</p>}

                {!readonly && (
                  <div className="flex justify-end mt-4">
                    <button type="submit" className="bg-[#5B8FCF] text-white font-semibold rounded-md px-6 py-2.5 hover:opacity-90">
                      Submit
                    </button>
                  </div>
                )}
              </div>
            </div>
          </form>
        )}
      </main>
    </div>
  );
}
