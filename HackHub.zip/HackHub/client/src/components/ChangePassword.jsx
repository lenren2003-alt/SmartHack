import {, useNavigate } from "react-router-dom";
import { useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import lockCloud from "@/assets/lock-cloud.png";

export const Route =("/change-password")({
  head: () => ({ meta: [{ title: "Change Password — SmartHack" }] }),
  component,
});

function ChangePasswordPage() {
  const navigate = useNavigate();
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  const handleConfirm = (e) => {
    e.preventDefault();
    if (!oldPassword || !newPassword || !confirmPassword) return setError("⚠️ All fields are required.");
    if (newPassword.length < 6) return setError("⚠️ New password must be at least 6 characters.");
    if (newPassword !== confirmPassword) return setError("⚠️ Passwords do not match.");

    // update current user's password in localStorage
    try {
      const session = JSON.parse(localStorage.getItem("smarthack_session") || "null");
      const users = JSON.parse(localStorage.getItem("smarthack_users") || "[]") { email: string; password: string }>;
      if (!session) return setError("⚠️ You must be logged in.");
      const me = users.find((u) => u.email === session.email);
      if (!me || me.password !== oldPassword) return setError("⚠️ Old password is incorrect.");
      const updated = users.map((u) => (u.email === session.email ? { ...u, password: newPassword } : u));
      localStorage.setItem("smarthack_users", JSON.stringify(updated));
      localStorage.setItem("smarthack_session", JSON.stringify({ ...session, password: newPassword }));
    } catch {
      return setError("⚠️ Could not update password.");
    }

    setError("");
    alert("Password changed successfully!");
    navigate("/settings");
  };

  const inputClass = "w-full mb-3 px-4 py-3 rounded-full bg-[#1f3a68] text-white placeholder-white/60 outline-none";

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader active="settings" />
      <div className="bg-[#5B8FCF] min-h-[calc(100vh-72px)] grid md:grid-cols-2 items-center px-6 py-10 gap-8 relative">
        <button onClick={() => navigate("/settings")} className="absolute right-6 top-6 text-white text-2xl">←</button>

        <div className="hidden md:flex justify-center">
          <img src={lockCloud} alt="Yellow padlock on cloud" loading="lazy" width={360} height={360} className="w-72 h-auto" />
        </div>

        <form onSubmit={handleConfirm} className="w-full max-w-md mx-auto">
          <h1 className="text-white text-3xl font-bold text-center mb-8">Change Password</h1>
          <input type="password" className={inputClass} placeholder="Old Password" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} />
          <input type="password" className={inputClass} placeholder="New Password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          <input type="password" className={inputClass} placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
          {error && <p className="text-red-100 text-sm text-center mb-3">{error}</p>}
          <div className="flex justify-center mt-2">
            <button type="submit" className="bg-[#cfe0f3] text-[#1f3a68] font-bold rounded-full px-10 py-2.5 hover:opacity-90">Confirm</button>
          </div>
        </form>
      </div>
    </div>
  );
}
