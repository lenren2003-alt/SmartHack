import {, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import {
  hackathonsForMentor,
  questionsForMentor,
  type Hackathon,
  type Question,
} from "@/lib/store";

export const Route =("/mentor-dashboard")({
  head: () => ({ meta: [{ title: "Mentor Dashboard — SmartHack" }] }),
  component,
});

function MentorDashboard() {
  const [items, setItems] = useState<Hackathon[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);

  useEffect(() => {
    setItems(hackathonsForMentor());
    setQuestions(questionsForMentor());
  }, []);

  const pending = questions.filter((q) => !q.answer);
  const answered = questions.filter((q) => q.answer);

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader active="dashboard" />
      <section className="bg-[#5B8FCF] py-6 text-center">
        <h1 className="text-2xl font-bold text-white">Mentor Dashboard</h1>
      </section>
      <main className="max-w-3xl mx-auto p-8 space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <StatTile value={items.length} label="Hackathons" />
          <StatTile value={pending.length} label="Pending Q's" highlight={pending.length > 0} />
          <StatTile value={answered.length} label="Answered" />
        </div>

        <div className="rounded-xl border bg-white p-6 shadow-sm">
          <h2 className="font-bold text-[#1f3a68] mb-3">Hackathons you're mentoring</h2>
          {items.length === 0 ? (
            <p className="text-sm text-gray-500">
              No hackathons assigned to you yet. An admin needs to assign you .
            </p>
          ) : (
            <ul className="space-y-2 text-sm text-gray-700">
              {items.map((h) => (
                <li key={h.id}>
                  •{" "}
                  <Link
                    to="/hackathon-details/$id"
                    params={{ id: h.id }}
                    className="text-[#5B8FCF] hover:underline"
                  >
                    {h.title}
                  </Link>{" "}
                  — {h.theme}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-xl border bg-white p-6 shadow-sm">
          <h2 className="font-bold text-[#1f3a68] mb-3">
            Pending questions {pending.length > 0 && <span className="text-red-600">({pending.length})</span>}
          </h2>
          {pending.length === 0 ? (
            <p className="text-sm text-gray-500">All caught up! 🎉</p>
          ) : (
            <ul className="space-y-2">
              {pending.map((q) => {
                const h = items.find((i) => i.id === q.hackathonId);
                return (
                  <li key={q.id} className="bg-yellow-50 border border-yellow-200 rounded p-3">
                    <p className="text-xs font-semibold text-[#1f3a68]">
                      {q.askerName} on{" "}
                      <Link
                        to="/hackathon-details/$id"
                        params={{ id: q.hackathonId }}
                        className="text-[#5B8FCF] hover:underline"
                      >
                        {h?.title || "hackathon"}
                      </Link>
                    </p>
                    <p className="text-sm text-gray-800 mt-1">{q.question}</p>
                    <Link
                      to="/hackathon-details/$id"
                      params={{ id: q.hackathonId }}
                      className="text-xs text-[#5B8FCF] hover:underline font-semibold mt-1 inline-block"
                    >
                      Answer →
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <Link to="/hackathons" className="block rounded-xl border bg-white p-6 shadow-sm hover:shadow-md">
          <h2 className="font-bold text-[#1f3a68]">Browse Hackathons</h2>
          <p className="text-sm text-gray-600 mt-1">View all hackathons.</p>
        </Link>
      </main>
    </div>
  );
}

function StatTile({ value, label, highlight }: { value: number; label: string; highlight?: boolean }) {
  return (
    <div
      className={`rounded-xl text-center py-5 ${
        highlight ? "bg-red-100 border border-red-300" : "bg-[#5B8FCF] text-white"
      }`}
    >
      <div className={`text-3xl font-bold ${highlight ? "text-red-700" : ""}`}>{value}</div>
      <div className={`text-xs font-semibold mt-1 ${highlight ? "text-red-700" : ""}`}>{label}</div>
    </div>
  );
}
